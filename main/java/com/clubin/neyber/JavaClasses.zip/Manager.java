package com.clubin.neyber;

/**
 * Created by Shruti on 7/27/15.
 */
public class Manager {
}
