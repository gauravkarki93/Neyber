package com.clubin.neyber;

import android.app.Activity;
import android.content.Context;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

public class GroupListAdapter extends BaseAdapter {

    Context context;
    List<GroupModel> rowItems;
    ArrayList<GroupModel> arrayList;

    GroupListAdapter(Context context, List<GroupModel> rowItems) {
        this.context = context;
        this.rowItems = rowItems;
        arrayList=new ArrayList<>();
        arrayList.addAll(this.rowItems);
    }

    @Override
    public int getCount() {
        return rowItems.size();
    }

    @Override
    public Object getItem(int position) {
        return rowItems.get(position);
    }

    @Override
    public long getItemId(int position) {
        return rowItems.indexOf(getItem(position));
    }

    /* private view holder class */
    private class ViewHolder {
        //ImageView profile_pic;
        TextView group_name;
        TextView info;
        TextView category;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {

        ViewHolder holder = null;

        LayoutInflater mInflater = (LayoutInflater) context.getSystemService(Activity.LAYOUT_INFLATER_SERVICE);
        convertView = mInflater.inflate(R.layout.list_view, null);
        holder = new ViewHolder();

        holder.group_name = (TextView) convertView.findViewById(R.id.member_name);
       // holder.profile_pic = (ImageView) convertView.findViewById(R.id.profile_pic);
        holder.info = (TextView) convertView.findViewById(R.id.status);
        holder.category = (TextView) convertView.findViewById(R.id.contact_type);

        GroupModel row_pos = rowItems.get(position);
       // holder.profile_pic.setImageResource(row_pos.getProfile_pic_id());
        holder.group_name.setText(row_pos.getGroupName());
        holder.info.setText(row_pos.getGroupInfo());
        holder.category.setText(row_pos.getGroupCategory());
        Log.d("Common", "adding groups");
        convertView.setTag(holder);
        return convertView;
    }

    public void filter(String newText) {
        rowItems.clear();
        if (newText.length() == 0) {
            rowItems.addAll(arrayList);
        }
        else
        {
            for (GroupModel ri : arrayList) {
                if (ri.getGroupName().toLowerCase(Locale.getDefault()).contains(newText))
                {
                    rowItems.add(ri);
                }
            }
        }
        notifyDataSetChanged();
    }
}