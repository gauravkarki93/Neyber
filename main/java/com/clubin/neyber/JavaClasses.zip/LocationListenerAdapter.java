package com.clubin.neyber;

import android.location.Location;
import android.location.LocationListener;
import android.os.Bundle;

/**
 * Created by Shruti on 7/30/15.
 */
public class LocationListenerAdapter implements LocationListener {
    @Override
    public void onLocationChanged(Location location) {

    }

    @Override
    public void onStatusChanged(String provider, int status, Bundle extras) {

    }

    @Override
    public void onProviderEnabled(String provider) {

    }

    @Override
    public void onProviderDisabled(String provider) {

    }
}
