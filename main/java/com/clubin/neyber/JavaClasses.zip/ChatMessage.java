//package com.clubin.neyber;
//
///**
// * Created by GAURAV on 30-06-2015.
// */
//public class ChatMessage {
//    public boolean left;
//    public String message;
//
//    public ChatMessage(boolean left, String message) {
//        super();
//        this.left = left;
//        this.message = message;
//}
//}
