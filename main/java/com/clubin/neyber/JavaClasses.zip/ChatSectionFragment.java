package com.clubin.neyber;

import android.app.Fragment;
import android.database.DataSetObserver;
import android.os.AsyncTask;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AbsListView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;

import com.google.android.gms.gcm.GoogleCloudMessaging;

import java.io.IOException;
import java.util.List;
import java.util.UUID;


/**
 * A simple {@link Fragment} subclass.
 * Activities that contain this fragment must implement the
 * {@link /ChatSectionFragment./OnFragmentInteractionListener} interface
 * to handle interaction events.
 * Use the {@link ChatSectionFragment#/newInstance} factory method to
 * create an instance of this fragment.
 */

public class ChatSectionFragment extends android.support.v4.app.Fragment {
    public static final String ARG_SECTION_NUMBER = "section_number";
    private static final String TAG = "ChatActivity";
    private ChatAdapter chatAdapter;
    private ListView listView;
    private EditText chatText;
    private Button buttonSend;
    private boolean side = false;
    private List<MessageModel> chatList;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View rootView = inflater.inflate(R.layout.activity_chat, container, false);
        buttonSend = (Button) rootView.findViewById(R.id.buttonSend);
        listView = (ListView) rootView.findViewById(R.id.list1);

        chatAdapter = new ChatAdapter(getActivity().getApplicationContext(),R.layout.activity_chat_singlemessage);
        listView.setTranscriptMode(AbsListView.TRANSCRIPT_MODE_ALWAYS_SCROLL);
        listView.setAdapter(chatAdapter);

        chatText = (EditText) rootView.findViewById(R.id.chatText);
        setHasOptionsMenu(true);
        buttonSend.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View arg0) {
                sendChatMessage();
            }
        });

        //to scroll the list view to bottom on data change
        chatAdapter.registerDataSetObserver(new DataSetObserver() {
            @Override
            public void onChanged() {
                super.onChanged();
                listView.setSelection(chatAdapter.getCount() - 1);
            }
        });

        return rootView;
    }

    @Override
    public void onResume() {
        super.onResume();
        chatList = (List<MessageModel>) new FileHandler().readFile(getActivity().getApplicationContext(),"ChatHistory");
        chatAdapter.setListToAdapter(chatList);
    }

    private boolean sendChatMessage() {
        final String id = nextMessageID();

        if (chatText.getText().equals(""))
            return false;

        final MessageModel newMessage = new MessageModel();
        newMessage.setMessage(chatText.getText().toString());
        newMessage.setMessageId(id);
        newMessage.setSenderId(ActiveProfile.getInstance().getId());
        newMessage.setSenderName(ActiveProfile.getInstance().getName());
        newMessage.setGroupId(GroupModel.getInstance().getGroupId());
        newMessage.setStat("Sending to Server");
        newMessage.setLeft(false);
        newMessage.setDate(new java.sql.Date(new java.util.Date().getTime()));

        new AsyncTask<Void, Void, String>() {
            @Override
            protected String doInBackground(Void... params) {
                String msg = "";
                try {
                    GoogleCloudMessaging gcm = GoogleCloudMessaging.getInstance(getActivity().getApplicationContext());
                    Bundle data = new Bundle();
                    data.putString("profileId", ActiveProfile.getInstance().getId());
                    data.putString("profileName", ActiveProfile.getInstance().getName());
                    data.putLong("groupId", GroupModel.getInstance().getGroupId());
                    data.putString("action", "com.clubin.neyber.BROADCAST");
                    data.putString("message", chatText.getText().toString());
                    data.putString("token", RegistrationIntentService.token);
                    Log.i("upstream", id);
                    gcm.send(getString(R.string.gcm_defaultSenderId) + "@gcm.googleapis.com", id, data);
                    msg = "Sent registration";

                    chatList= (List<MessageModel>) new FileHandler().readFile(getActivity().getApplicationContext(),"ChatHistory");
                    chatList.add(newMessage);
                    new FileHandler().createFile(getActivity().getApplicationContext(),chatList,"ChatHistory");
                } catch (IOException ex) {
                    msg = "Error :" + ex.getMessage();
                }
                return msg;
            }
            @Override
            protected void onPostExecute(String msg) {
//                    Toast.makeText(appContext, msg, Toast.LENGTH_SHORT).show();
            }
        }.execute();

        chatAdapter.add(newMessage);
        chatText.setText("");
        return true;
    }


    public String nextMessageID()
    {
        return "m-" + UUID.randomUUID().toString();
    }


    @Override
    public void onCreateOptionsMenu(Menu menu, MenuInflater inflater) {
        MenuItem item = menu.findItem(R.id.action_attach);
        item.setVisible(true);
        item = menu.findItem(R.id.action_newQues);
        item.setVisible(false);

        super.onCreateOptionsMenu(menu, inflater);
    }
}
//public class ChatSectionFragment extends Fragment {
//    // TODO: Rename parameter arguments, choose names that match
//    // the fragment initialization parameters, e.g. ARG_ITEM_NUMBER
//    private static final String ARG_PARAM1 = "param1";
//    private static final String ARG_PARAM2 = "param2";
//
//    // TODO: Rename and change types of parameters
//    private String mParam1;
//    private String mParam2;
//
//    private OnFragmentInteractionListener mListener;
//
//    /**
//     * Use this factory method to create a new instance of
//     * this fragment using the provided parameters.
//     *
//     * @param param1 Parameter 1.
//     * @param param2 Parameter 2.
//     * @return A new instance of fragment ChatSectionFragment.
//     */
//    // TODO: Rename and change types and number of parameters
//    public static ChatSectionFragment newInstance(String param1, String param2) {
//        ChatSectionFragment fragment = new ChatSectionFragment();
//        Bundle args = new Bundle();
//        args.putString(ARG_PARAM1, param1);
//        args.putString(ARG_PARAM2, param2);
//        fragment.setArguments(args);
//        return fragment;
//    }
//
//    public ChatSectionFragment() {
//        // Required empty public constructor
//    }
//
//    @Override
//    public void onCreate(Bundle savedInstanceState) {
//        super.onCreate(savedInstanceState);
//        if (getArguments() != null) {
//            mParam1 = getArguments().getString(ARG_PARAM1);
//            mParam2 = getArguments().getString(ARG_PARAM2);
//        }
//    }
//
//    @Override
//    public View onCreateView(LayoutInflater inflater, ViewGroup container,
//                             Bundle savedInstanceState) {
//        // Inflate the layout for this fragment
//        return inflater.inflate(R.layout.fragment_chat_section, container, false);
//    }
//
//    // TODO: Rename method, update argument and hook method into UI event
//    public void onButtonPressed(Uri uri) {
//        if (mListener != null) {
//            mListener.onFragmentInteraction(uri);
//        }
//    }
//
//    @Override
//    public void onAttach(Activity activity) {
//        super.onAttach(activity);
//        try {
//            mListener = (OnFragmentInteractionListener) activity;
//        } catch (ClassCastException e) {
//            throw new ClassCastException(activity.toString()
//                    + " must implement OnFragmentInteractionListener");
//        }
//    }
//
//    @Override
//    public void onDetach() {
//        super.onDetach();
//        mListener = null;
//    }
//
//    /**
//     * This interface must be implemented by activities that contain this
//     * fragment to allow an interaction in this fragment to be communicated
//     * to the activity and potentially other fragments contained in that
//     * activity.
//     * <p/>
//     * See the Android Training lesson <a href=
//     * "http://developer.android.com/training/basics/fragments/communicating.html"
//     * >Communicating with Other Fragments</a> for more information.
//     */
//    public interface OnFragmentInteractionListener {
//        // TODO: Update argument type and name
//        public void onFragmentInteraction(Uri uri);
//    }
//
//}
