package com.clubin.neyber;

import android.app.Activity;
import android.content.Context;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import java.util.List;

/**
 * Created by GAURAV on 13-07-2015.
 */
public class QuesAdapter extends BaseAdapter {

    Context context;
    List<QuesModel> rowItems;

    QuesAdapter(Context context, List<QuesModel> rowItems) {
        this.context = context;
        this.rowItems = rowItems;
    }

    @Override
    public int getCount() {
        return rowItems.size();
    }

    @Override
    public Object getItem(int position) {
        return rowItems.get(position);
    }

    @Override
    public long getItemId(int position) {
        return rowItems.indexOf(getItem(position));
    }

    private class ViewHolder {
        TextView user;
        TextView ques;
        TextView date;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {

        ViewHolder holder = null;

        LayoutInflater mInflater = (LayoutInflater) context.getSystemService(Activity.LAYOUT_INFLATER_SERVICE);
        convertView = mInflater.inflate(R.layout.qa_card, null);
        holder = new ViewHolder();

        holder.user = (TextView) convertView.findViewById(R.id.from);
        //holder.date = (TextView) convertView.findViewById(R.id.date);
        holder.ques = (TextView) convertView.findViewById(R.id.ques);

        QuesModel row_pos = rowItems.get(position);
        holder.user.setText(row_pos.getProfileId());
        Log.i("Common","ID:"+row_pos.getProfileId());
        //holder.date.setText(row_pos.getDate());
        holder.ques.setText(row_pos.getQues());
        Log.i("Common", "ques:" + row_pos.getQues());
        convertView.setTag(holder);
        return convertView;
    }

}
