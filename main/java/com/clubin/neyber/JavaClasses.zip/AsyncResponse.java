package com.clubin.neyber;

/**
 * Created by Shruti on 8/3/2015.
 */
public interface AsyncResponse {
    void processResult(boolean profileExists);
}
